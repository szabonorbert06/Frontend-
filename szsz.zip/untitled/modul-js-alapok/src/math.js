export const PI = 3.14159;

export function circleArea(r){
    return r * r * PI;
}
export default function sum(a, b){
    return a + b;
}