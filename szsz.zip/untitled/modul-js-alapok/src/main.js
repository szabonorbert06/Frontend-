import'./style.css'
import {renderHome} from "./pages/home.js";
import {renderList} from "./modules/ui/renderList.js";

const app = document.querySelector('#app');
app.appendChild(renderHome());

//Dinamikus import példa
document.querySelector('#dynamicBtn').addEventListener('click', async () => {
    const {getPosts} = await import('./modules/apiClient.js');
    const posts = await getPosts();
    const titles = posts.map(p => p.title)
    app.appendChild(renderList(titles));
});

//TLA import: demo
document.getElementById('tlaBtn').addEventListener('click', async () =>{
    const mod = await import('./modules/apiClient.js');
    console.log('Mock config: ', mod.config)
    alert("Nézd meg a konzolt")
})
