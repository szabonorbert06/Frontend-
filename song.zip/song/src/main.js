import  'bootstrap'
import  'bootstrap/dist/css/bootstrap.min.css'
import  'bootstrap-icons/font/bootstrap-icons.css'
// requestAnimationFrame(()=>{
//     import ( 'bootstrap-icons/font/bootstrap-icons.css')
// })

import { createApp } from 'vue'
import App from './App.vue'

createApp(App).mount('#app')
