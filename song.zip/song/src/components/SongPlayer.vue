<script>
export default {
  name: "SongPlayer",
  props: {
    song: {type: Object, required: true, default: null},
    isPlaying: {type: Boolean, required: true, default: false},
    repeat: {type: Boolean, required: true, default: false},
    volume: {type: Number, required: true, default: 0.8},
  },
  data() {
    return {
      currentTime: 0,
      duration: 0,
      seekValue: 0,
      isSeeking: false,
      volumeLocal: 0
    };
  },
  watch: {
    song: {
      immediate: true,
      handler() {
        this.loadSong()
      }
    },
    isPlaying(newValue) {
      if (newValue) {
        this.play();
      } else {
        this.pause();
      }
    },
    volume(newValue) {
      this.volumeLocal = newValue;
      this.applyVolume();
    }
  },
  mounted() {
    const audio = this.$refs.audio;
    if (!audio) return;
    audio.addEventListener('timeupdate', this.onTimeUpdate)
    audio.addEventListener('loadedmetadata', this.onLoadMetadata)
    audio.addEventListener('ended', this.onEnded);
    this.applyVolume();
  },
  beforeUnmount() {
    const audio = this.$refs.audio;
    if (!audio) return;
    audio.addEventListener('timeupdate', this.onTimeUpdate)
    audio.addEventListener('loadedmetadata', this.onLoadMetadata)
    audio.addEventListener('ended', this.onEnded);
  },
  methods: {
    togglePlay() {
      this.$emit("togglePlay");
    },
    loadSong() {
      const audio = this.$refs.audio;
      if (!audio || !this.song) return;
      this.currentTime = 0;
      this.duration = 0;
      this.seekValue = 0;

      audio.src = this.song.audioUrl;
      audio.load();
      if (this.isPlaying) this.play()
    },
    async play(){
      const audio = this.$refs.audio;
      if (!audio) return;
      try{
        await audio.play();
      }catch(e){
        this.$emit('playError',e);
      }
    },
    pause(){
      const audio = this.$refs.audio;
      if (!audio) return;
      audio.pause();
    },
    onLoadMetadata(){
      const audio = this.$refs.audio;
      if (!audio) return;
      this.duration = isFinite(audio.duration) ? audio.duration : 0;
    },
    onTimeUpdate(){
      if(this.isSeeking) return;
      const audio = this.$refs.audio;
      if (!audio) return;
      this.currentTime = audio.currentTime || 0;
      this.seekValue = this.currentTime;
    },
    onSeekChange(){
      const audio = this.$refs.audio;
      if (!audio) return;
      audio.currentTime = this.seekValue;
      this.currentTime = this.seekValue;
      this.isSeeking = false;
    },
    applyVolume(){
      const audio = this.$refs.audio;
      if (!audio) return;
      const v = Math.min(1, Math.max(0, this.volumeLocal))
      audio.volume = v;
      this.$emit('update:volume', v);
    },
    onEnded(){
      this.$emit('ended');
    },
    formatTime(totalSeconds){
      const s = Math.max(0, Number(totalSeconds) || 0);
      const mm = Math.floor(s / 60);
      const ss = Math.floor(s % 60);
      return `${mm}:${ss}${String(ss).padStart(2, '0')}`;
    }
  }
}
</script>

<template>
  <section class="card h-100">
    <div class="card-header fw-semibold">Lejátszó</div>
    <div class="card-body" v-if="song">
      <div class="d-flex gap-3 align-items-center mb-3">
        <img :src="song.coverUrl" :alt="song.title" width="84" height="84" class="rounded"/>
      </div>
      <div>
        <div class="h5 mb-1">{{ song.title }}</div>
        <div class="text-muted small">{{ song.artist }} <i class="bi bi-dot"></i> {{ song.album }}</div>
        <div class="text-muted small">{{ song.genre }} <i class="bi bi-dot"></i> {{ song.year }}</div>
      </div>
      <audio ref="audio" preload="metadata"></audio>
      <div class="d-flex gap-2 flex-wrap mb-3">
        <button class="btn btn-outline-secondary" type="button" @click="$emit('prev')"><i
            class="bi bi-caret-left-fill"></i></button>
        <button type="button" class="btn btn-primary" @click="togglePlay">
          <i v-if="isPlaying" class="bi bi-pause"></i>
          <i v-else class="bi bi-play"></i>
        </button>
        <button class="btn btn-outline-secondary" type="button" @click="$emit('next')"><i
            class="bi bi-caret-right-fill"></i></button>
        <button type="button" class="btn" :class="repeat ? 'btn-success': 'btn-outline-success' "><i
            class="bi bi-repeat-1"></i></button>
      </div>

      <div class="mb-3">
        <div class="d-flex justify-content-between small text-muted mb-1">

        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
img {
  object-fit: cover;
}
</style>